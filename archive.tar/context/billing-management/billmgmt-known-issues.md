# Billing Module — Known Issues & Deferred Items

Living record of known-but-not-yet-fixed issues in the Bill Run module, captured
from the bm09–bm11 multi-agent code review (see also
`billmgmt-progress-tracker.md`). Each entry has a technical description, an
**ELI5** plain-language summary, and a recommendation. Most entries are not blockers
for the current release; they are logged so they are not silently forgotten. The
end-to-end blocker in §9 (processor signal-back) has been **RESOLVED by bm36** —
the signal-back is now real. Phase 4 is delivered: bm37 added the local
`SCHEDULED → COMPLETED` live-Kestra lifecycle assertion, bm38 made the production
deploy path deployable + wired (still gated), and **bm39 audited the assembled
phase against its guardrails and signed it off** (§9 resolved, §10 ratified, no new
schema). The cloud cutover itself remains a gated ops step (see
`billmgmt-update-overview.md` and `billmgmt-progress-tracker.md`).

**§11–§14 and §4c were added on 2026-09-17**, from the first
end-to-end local execution of the full `SCHEDULED → COMPLETED` lifecycle
(processing, approval, posting and distribution all driven against real
Postgres, real Kestra and Azurite). Defects that run surfaced and FIXED are
recorded in `billmgmt-progress-tracker.md` and `README.md`; the entries here
are the ones still OPEN, plus the two interim mitigations whose root cause
(§11) is unaddressed.

> **Status legend:** 🟡 deferred (conscious decision) · 🔴 real bug, out of
> current scope · ⚪ cosmetic / low priority.

---

## 1. ⚪ `postRun` returns an unused `results` array (review #14)

**Where:** `services/billing/post-run.ts` — `PostRunResult.value.results`.

**Technical.** `postRun` returns a `results: { billingAccountId, result }[]`
array describing each account's per-post outcome (`invoiced` / `skipped` /
`parked` + `code`/`detail`). No production caller consumes it: the action
(`actions/billing/post-run.action.ts`) only checks `result.ok`, and
`PostingProgressView` re-derives everything from `getPostingProgress` after
`router.refresh()`. It is effectively a dead payload on the hot path.

**Why it's still here (intentional).** The unit suite
(`tests/services/billing/post-run.service.test.ts`) asserts on `results` to
verify per-account behaviour (invoiced vs. parked vs. skipped) without a DB.
Removing `results` would reduce that test observability for zero functional
gain. The redundant *second* full status scan that used to accompany it **has**
been removed (completion is now decided inside the locked transaction).

**ELI5.** The posting function hands back a little report card of what happened
to each account, but the screen ignores it and just re-reads the database
instead. The report card is only used by tests. It's harmless — just slightly
redundant.

**Recommendation.** Leave as-is, or (if trimming) keep the shape but have the UI
consume `results` directly instead of re-fetching. Low priority.

---

## 2. 🔴 No DB-level "one INV per bill" latch (review #9)

**Where:** `db/schema/billing/customer-bill.ts` (`ref_inv_document_id`) +
`services/billing/post-run.ts` / `customer-bill.repository.ts`.

**Technical.** "At most one posted INV per (run, account)" is enforced entirely
in the application layer:
1. `lockBillForPosting` takes `FOR UPDATE OF customer_bill` so two concurrent
   posts of the same account serialize on the bill row; the loser reads the
   now-set `ref_inv_document_id` and returns `skipped`.
2. `stampPosted` is `WHERE ref_inv_document_id IS NULL`-guarded and returns
   whether it wrote a row; `postAccount` throws (rolling back the INV) if it
   didn't.

There is **no schema-level constraint** guaranteeing this. The only DB
constraint on `customer_bill` is `UNIQUE (run, ban, period)` — one *bill* row —
which says nothing about `ref_inv_document_id` being set at most once, and the
actual INV lives in the separate `billing.document` table with no FK back to the
bill. So if a *future* code path ever posts outside this exact lock discipline
(a new caller, a lock downgrade, a replica read), two INV documents against one
bill become possible with no backstop — a double-billed customer + duplicate GL
posting.

**Why deferred.** A *meaningful* DB backstop needs a `document → customer_bill`
linkage (or a dedicated posted-latch table) — a schema redesign beyond the
review's scope. A partial unique index on `customer_bill (run, ban) WHERE
ref_inv_document_id IS NOT NULL` does **not** actually prevent the failure (the
duplicate lives in `document`, and there's already one bill row per key). The
current app-layer guards are correct and were hardened in this review; the risk
is strictly "if someone later bypasses them".

**ELI5.** We stop the same invoice from being created twice by having the code
"lock the door" while it works. That works today. But the *database itself*
doesn't enforce the rule — so a future developer who forgets to lock the door
could accidentally bill a customer twice. We'd need a small database redesign to
make that mistake impossible.

**Recommendation.** When a rating/finalization schema change is next on the
table, add a `document.ref_customer_bill_id` FK + a partial unique index (or a
posted-latch table) so duplicate INV creation is structurally impossible; demote
the app-layer checks to a friendly early-return.

---

## 3. ⚪ Duplicated error-vocabulary / badge patterns (review #15)

**Where:** several billing + accounts UI and service files.

**Technical.** The same small mappings are hand-written in multiple places:
- **`describePostFailure`** (postDocument codes → prose) in
  `services/billing/post-run.ts` duplicates the same code→message mapping in
  ~12 accounts panels (allocate-payment, capture-deposit/payment, raise-debit/
  credit-note, write-off, rounding-adjustment, reversal-dialog, …).
- **`describeError`** for the shared action-envelope codes
  (`FORBIDDEN` / `VALIDATION_ERROR` / fallback) is re-declared in
  `approve-and-post-panel.tsx`, `posting-progress-view.tsx`,
  `trigger-run-dialog.tsx`, and `rerun-dialog.tsx`.
- **`periodKeyFor`** (a `YYYY-MM` accounting-period key) exists in both
  `services/billing/pre-approval-checks.ts` and
  `services/accounts/post-document.ts` (plus two `to_char(..,'YYYY-MM')` SQL
  sites).
- **Status-badge cva** — `posting-progress-view.tsx` inlines a
  badge-variants block instead of a `PostingStatusBadge` component alongside the
  five existing per-status badges.

**Why deferred.** The highest-value target (`describePostFailure` across ~12
panels) lives **outside** the bm09–bm11 diff; refactoring it touches many
unrelated Accounts files for low functional gain and non-trivial churn/risk.

**ELI5.** A few error messages and little UI badges are copy-pasted in several
files instead of being written once and shared. Nothing is broken, but if
someone changes wording in one place they have to remember all the copies, and
they can drift apart over time.

**Recommendation.** Opportunistically extract, when a file is next touched for
another reason: (a) a shared `describePostDocumentError(code)` helper, (b) a
shared `describeBillingActionEnvelopeError(code)` helper for
`FORBIDDEN`/`VALIDATION_ERROR`, (c) one `periodKeyFor` helper in `lib/`, and (d)
a `PostingStatusBadge` component.

---

## 4. 🔴 Pre-existing integration-test failures surfaced during testing

Discovered while running the full integration suite against a throwaway
Postgres. These **fail identically on the base commit** (`2efa01b`) and are
**not** caused by the bm09–bm11 review fixes — but they are real and worth a
follow-up. All are outside the bm09–bm11 scope (they live in bm02/bm03).

### 4a. Materialize / trigger generate an invalid `2026-02-29` date

**Where:** `tests/db/materialize-runs.integration.test.ts`,
`tests/db/billing-schema.integration.test.ts` (bill-run insert path).

**Technical.** With the business clock at 2026-08-23, the run-date computation
produces `2026-02-29` — but **2026 is not a leap year**, so Postgres rejects the
`date` value (`22008 date/time field value out of range`). This points at a
month-end/day-clamping bug in the bill-run period/scheduled-date derivation
(a `cycle_day` near month-end not being clamped to the month's real last day).

**ELI5.** The code tried to schedule something for "February 29th, 2026", but
that day doesn't exist (2026 isn't a leap year), so the database refused it. The
date math needs to clamp to the last real day of the month.

### 4b. `trigger-run` double-trigger test hits a duplicate-key

**Where:** `tests/db/trigger-run.integration.test.ts` — "rejects a second
trigger while the run is already PROCESSING".

**Technical.** The test's `newScheduledRun` inserts a `bill_run` for
`(BCY00000001, 2026-06-01)` that already exists → `23505` unique violation on
`bill_run_cycle_period_unique`, i.e. a test-isolation/ordering issue (a prior
step in the file created the row and it isn't reset between cases).

**ELI5.** A test tries to create the same bill run twice and trips over the
"no duplicates" rule — a test-setup cleanup gap, not a product bug.

### 4c. Both full-journey E2E suites fail at post → distribute (UNTRIAGED)

**Where:** `tests/db/billing-e2e-happy-path.integration.test.ts:776`,
`tests/db/billrun-phase3-journey.integration.test.ts:747`.

**Technical.** Surfaced on 2026-09-17 by the **first full DB-gated run** against a
disposable Postgres (89 files passed, 2 skipped, 2 failed; 813 tests passed).
Both fail the same assertion — `expected 'INVOICED' to be 'DISTRIBUTING'`:
posting settles the run at `INVOICED`, but the post-commit `triggerDistribution`
does not advance it. `distribute-run.ts` rolls its transaction back and returns
`ENGINE_UNREACHABLE` when `engineRegistry.trigger` throws, which is consistent
with the observed state but was **not** confirmed as the cause. The suites are
also sensitive to ambient environment beyond `DATABASE_URL`: re-running
`billrun-phase3-journey` with a dev `.env` also exported fails **earlier**
instead (line 568), so the two runs are not directly comparable.

**ELI5.** The two tests that walk a bill run from start to finish both stop at
the same step — after invoicing, the run never moves on to delivery. Nobody has
worked out why yet.

**Not a regression.** The progress tracker had listed this full DB-gated run as a
gated verification step that had never been executed, so these are
first-execution results, not something that broke.

**Recommendation.** File a bm02/bm03 ticket: (1) clamp scheduled-run/period-end
dates to the month's real last day (fixes 4a), and (2) fix the trigger test's
per-case isolation (fixes 4b). Both are date/fixture issues, unrelated to the
approve/post work.

**4c is separate and untriaged** - it is a post→distribute lifecycle question,
not a date/fixture issue, and needs its own investigation before a ticket can
name a fix.

---

## 5. ⚪ Approve-page & period-close query efficiency (deferred perf pass)

Flagged by the bm09-11 review's efficiency finders. All are **per-render / per-
close** waste (not a hot per-account loop) with **no correctness impact**, so
they are deferred to a dedicated performance pass rather than reshaping the
heavily-tested approval-check module now.

**Technical.**
- **Redundant reads on the Approve preview.** `getApprovePreview` (force-dynamic
  RSC) calls `listPostableCurrencies` once, and `runPreApprovalChecks` re-runs
  it inside both `checkPeriodOpen` and `checkGlMappingsResolvable` — **3× the
  same `customer_bill ⋈ billing_account ⋈ bill_run_account` DISTINCT join per
  render**. `listStatusesForRun` is likewise read twice (preview counts +
  `checkAccountsTerminal`). Fix: compute currencies + statuses once and thread
  them into `runPreApprovalChecks` (optional precomputed params).
- **Wide audit fetch to pluck one actor.** `getApprovePreview` uses
  `auditLogRepository.findByTargetId` (all rows, full `beforeData`/`afterData`
  blobs) only to `.find()` the newest trigger/rerun actor. Fix: a targeted
  `findLatestActorForEvents(db, runId, TRIGGER_EVENT_TYPES)` returning just the
  name + timestamp.
- **No partition pruning on approval reads.** `listPostableCurrencies` /
  `countNonPositivePostable` / `sumPostableTotalForRun` join the two
  `PARTITION BY RANGE(period_partition)` tables WITHOUT the `period_partition`
  predicate `lockBillForPosting` now has, so they scan every monthly partition.
  Fix: add the `firstOfMonth(run.periodStart)` predicate (a signature change to
  those methods + callers).
- **Non-sargable period-close guard.** `findActiveForPeriod` filters
  `to_char(gl_event_at, 'YYYY-MM') = period` (seq-scans all of `bill_run`; no
  index on `gl_event_at`). Fix: a sargable range predicate + a `gl_event_at`
  index (migration).

**ELI5.** Opening the Approve page runs a handful of the same database lookups
several times, and closing a period scans the whole run history. Nothing is
wrong — it's just slower than it needs to be, and it gets slower as more months
of data pile up. Worth batching later; not urgent.

**Recommendation.** One perf pass: dedup the approval reads (thread
currencies/statuses), add the partition predicate to the three approval reads,
add the `gl_event_at` index + sargable close guard, and a targeted latest-actor
read.

---

## 6. 🟡 Four-eyes leans on the audit log for rerun-actor coverage (latent)

`checkFourEyes` bars every actor in the `BILL_RUN_TRIGGERED`/`BILL_RUN_RERUN`
audit trail (∪ `bill_run.triggered_by`) from approving — the intended, stronger
segregation-of-duties rule ("Ops triggers/reruns, a Manager approves"). Two
latent edge cases, **neither reachable in v1**:

- **Lockout:** if a run were triggered with a **null** actor (a system/cron
  path) leaving `triggered_by` null AND no audit rows, the barred set is empty
  and the check fails closed → no one can approve. (v1 always triggers via a
  user action that stamps `actorId`, so this can't happen; the old
  `triggered_by`-only check had the same null-fail-closed behaviour.)
- **Bypass:** if a rerun's `BILL_RUN_RERUN` audit row had a **null** actor
  (dropped by the set), that rerunner wouldn't be barred. (v1 rerun always
  stamps a user; audit rows for a run being approved are days old, far inside
  the 7-year retention, so pruning is not a factor.)

**ELI5.** We decide who's *not allowed* to approve by reading the run's history
log. Today every trigger/rerun is stamped with a real person, so it works. If a
robot ever triggered a run without a name, the rule could either lock everyone
out or miss the robot — but no robot does that today.

**Recommendation.** If a system/automation trigger path is ever added, make the
barred-actor set authoritative in `bill_run` state (a dedicated `triggered_by` /
`reran_by` actors column or a small `bill_run_actors` table written at
trigger/rerun) rather than re-deriving it from the prunable audit log.

---

## 7. 🟡 Multi-currency total shown in the Approve preview (latent)

Single-currency-per-cycle is a v1 invariant, and `approveRun` already **blocks**
a multi-currency run with `MULTI_CURRENCY`. But `getApprovePreview` still
displays `currency = currencies[0]` with `totalAmount =
sumPostableTotalForRun` (a blind cross-currency SUM), so a (hypothetical)
multi-currency run would show a meaningless single-currency figure until the
operator clicks and hits the block.

**ELI5.** If a run ever mixed dollars and euros (it can't today), the review
screen would show one wrong combined number; you'd only find out it's blocked
when you press Approve. Harmless now because runs are single-currency.

**Recommendation.** When the preview computes currencies, surface `>1` up front
(a `single_currency` pre-approval check or a preview flag) instead of only at
the write path.

---

## 8. ⚪ Minor items (bm09-11 review, low severity)

- **`INV_LEG_TEMPLATES` non-null aliases.** `charge: DBN_LEG_TEMPLATES.charge!`
  uses the file's established `!` idiom (cf. `refund: PAY_LEG_TEMPLATES.refund!`);
  if a DBN key were ever removed the INV template would silently be `undefined`
  and fail at first post rather than at compile. Left as-is for idiom
  consistency; a shared `requireLegTemplate()` load-time assert would close it.
- **Stale four-eyes checklist on submit.** If a viewer becomes a barred actor
  *between* page-load and submit, `ApproveAndPostPanel` shows the
  `FOUR_EYES_VIOLATION` error text but doesn't refresh the checklist (only
  `CHECKS_FAILED` calls `setChecks`), so `four_eyes` still renders green with the
  button enabled. Cosmetic — the service still refuses. Refresh the checklist on
  `FOUR_EYES_VIOLATION` to fix.

---

## 9. 🟢 RESOLVED (bm36) — Processor signal-back is real

**Where:** `workflow-management/flows/bill-run-processor/local-dev/bill_run_processing.yml`
(per-stage completion + terminal `errors`/`afterExecution`); the non-deployable
`bill_run_processing.template.yml` documents the same contract.

**Was.** The processing flow did all its real SQL (correlation/claim, aggregation,
verification) but never signalled the app: it contained **zero**
`io.kestra.plugin.core.http.Request` tasks — the per-stage
`/api/billrun/{runId}/stage/{stage}/complete` POSTs and the terminal
`/api/billrun/{runId}/status` POST were `io.kestra.plugin.core.log.Log` stubs, so a
triggered run's accounts never auto-reached `PROCESSED`
(`TERMINAL_STAGE = 'verification'` in `services/billing/handle-stage-signal.ts`),
the run wedged in `PROCESSING`, and Approve → Post → Distribute → `COMPLETED` was
unreachable without an out-of-band signal replay.

**Now (bm36).** The flow POSTs a per-stage `DONE` after each stage, a per-account
HARD `FAILED` from the account stage group's `errors` handler (to a fixed
`verification` stage so it always lands), and a run-level terminal
`PROCESSING_FAILED` for a whole-execution failure only — `errors: on_error` on a
`FAILED` execution, `afterExecution: on_killed` on a KILL. All real
`http.Request`, mirroring the distributor (bm34). A triggered run now reaches
`PROCESSED` on its own; a contained per-account HARD failure leaves the run
`PROCESSED` with the failed account skippable/rerunnable (the tested run-status
contract), and only a whole-execution `FAILED`/`KILL` settles the run
`PROCESSING_FAILED`.

**Delivered (Phase 4, closed).** bm37 asserts the full `SCHEDULED → COMPLETED`
lifecycle on the `ci` seed (incl. reject → reprocess and the forced-failure path)
via the live-Kestra smoke; bm38 wired the production deploy path (deployable +
gated); bm39 audited the assembled phase (guardrails green, receivers unchanged, no
new schema) and signed it off. The live cloud cutover — flipping the deploy flags
and running the smoke against a real engine + SFTP — remains a gated ops step. Scope
in `billmgmt-update-overview.md`.

---

## 10. 🟡 Taxation stage is a no-op — every bill is zero-tax

**Where:** `bill_run_processing.yml` `taxation` stage (a `Log` placeholder).

**Technical.** The `taxation` stage computes nothing: `customer_bill.tax_total` is
always `"0.00"` and `total_amount = subtotal`. The `customer_bill_tax_item` table
and the single-rate `BILLRUN_TAX_RATE` config exist (bm06) but no tax line is
written by the real flow.

**ELI5.** The processor doesn't calculate tax yet — every invoice shows zero tax.

**Recommendation.** Ratified as the intended interim (Phase 4 decision) — invoices
show `total = subtotal`. Implement a real (flat-rate SST, then jurisdictional)
taxation stage in a later unit if RevOps needs a tax line on the reviewed invoice.

---

## 11. 🔴 The processor writes a zero-total bill for a zero-charge account

**Where:** `workflow-management/flows/bill-run-processor/local-dev/bill_run_processing.yml`
- the `aggregation` stage's `ins_header` CTE.

**Technical.** `ins_header` is a data-modifying CTE, so it runs **exactly once
per account regardless of whether `all_lines` is empty**; the flow's own comment
calls this "the deferred limitation". An account with no subscription and no
rated usage therefore gets a `customer_bill` header with `subtotal` and
`total_amount` of `0.00` and zero `customer_bill_line` rows. Since **bm32**
redefined Uncharged (Inv #22), such an account is scoped, `PROCESSED`, and
surfaced on the Uncharged tab — so the empty header is the only artefact of it,
and everything else already expects it NOT to exist: Verification guards with
`IF v_total IS NOT NULL` and treats a non-positive total as a **SOFT, advisory,
non-blocking** NOTICE, and `listUnchargedForRun`'s `HAVING` keeps accounts with
"NO bill/line".

**Blast radius (all observed live on the `ci` seed's `BAN...04`).** The stray
header broke the lifecycle twice in succession:

1. **At approval** — `positive_totals` counted it, making *any* run containing a
   no-charges account permanently unapprovable.
2. **At posting** — posting inserts the revenue line at `amount = subtotal`, so
   `document_line_amount_check` (`amount > 0`) rejected it and parked the account
   at `POSTING_FAILED` with an opaque "An unexpected error occurred while posting
   this invoice."

**ELI5.** For a customer with nothing to bill, the system still creates a blank
zero-value invoice. Nothing wants that blank invoice, and it jammed first the
approval step and then the posting step.

**Two interim mitigations are in place (owner decisions, 2026-09-17).** Both
treat the symptom; neither removes the cause:

- `countNonPositivePostable` now ignores **line-less** zero bills, and the new
  informational `zero_total_bills` check reports them
  (`specs/bm10-approve.md` checks 3 and 6).
- `postAccount` skips a bill whose `subtotal` **and** `total_amount` are both
  exactly zero, marking the account `SKIPPED` / `ZERO_TOTAL_NOT_INVOICED`
  (`specs/bm11-post-to-ledger.md` step 1b).

**Recommendation.** Make `ins_header` conditional on `all_lines` being non-empty,
so a zero-charge account produces no bill at all. That was the engineering
recommendation before each mitigation; the owner chose the mitigations to unblock
the demo. Keep the posting skip afterwards as a second line of defence, and
revisit the approval narrowing (§12) at the same time.

---

## 12. 🟡 The zero-total predicates will misfire on a fully-discounted bill

**Where:** `services/billing/post-run.ts` (`postAccount`'s zero-total skip) and
`db/repositories/billing/customer-bill.repository.ts`
(`countNonPositivePostable`).

**Not a revenue-recognition issue — corrected 2026-09-17.** An earlier draft of
this entry claimed the skip would "suppress real revenue". That was wrong, and
the correction matters because it changes what the fix is for. A bill charged
100 and discounted 100 has a transaction price of **zero**; net IS the revenue.
Posting inserts the GL revenue line at `amount = bill.subtotal`, i.e. **net**, so
whether such a bill posts or not the P&L impact is identically `0.00`. Nor is the
gross-to-net record lost: `customer_bill_line` persists `gross_amount`,
`discount_amount`, `discount_amount_raw` and `net_amount` independently of
posting, so discount analytics survive a skip. **There is no accounting exposure
here.**

**Technical — what the real exposure is.** Both predicates key on a bill
totalling exactly zero, which today can only mean "no charge". Once discounting
lands it can also mean "fully discounted", and the two are then
indistinguishable:

1. **A fully-discounted account wedges the whole run at approval.**
   `countNonPositivePostable` is `(subtotal <= 0 OR total_amount <= 0) AND
   EXISTS(lines)`. A discounted-to-zero bill HAS lines, so it is counted,
   `positive_totals` fails, and **no account in that run can be approved** until
   someone intervenes. This is the same operational jam as §11, re-armed for a
   legitimate account — and it is the more likely of the two to be hit.
2. **If unblocked, the customer gets no invoice.** `postAccount`'s skip is
   `subtotal == 0 AND total_amount == 0` with no line check, so the account
   settles `SKIPPED` / `ZERO_TOTAL_NOT_INVOICED` and no INV document is produced
   — for an account that had genuine billable activity. The customer never
   receives a document showing the charge and the discount that cancelled it,
   which is a contractual/transparency question for RevOps, not a ledger one.
3. **Operators cannot tell the two apart.** A 100%-discounted account and an
   account with nothing to bill both land as `SKIPPED` with the same reason code
   and both appear on the Uncharged tab.

**ELI5.** "This invoice totals zero" currently always means "there was nothing to
bill". After discounts exist it can also mean "we charged 100 and took 100 off".
The money is the same either way — zero — so nothing is misstated. The problem is
that the system treats the second case as if the customer were idle: it first
refuses to approve the entire run because of it, and if you force past that, it
quietly issues no invoice, so the customer never sees the discount they were
given.

**Interaction with §11 — important.** Fixing §11 does **not** fix this. A
discounted-to-zero bill has lines, so §11's fix (only create a header when there
ARE lines) correctly still creates it, and both predicates still misread it. What
§11's fix DOES do is remove the only legitimate reason those predicates exist:
with no line-less bills in the system, the `EXISTS(lines)` narrowing is redundant
and the posting skip's **only remaining reachable case is the harmful one**. So
the mitigations should be removed or re-keyed as part of the §11 fix, not left
behind.

**Recommendation.** When §11 is fixed, in the same change: drop the
`EXISTS(lines)` clause from `countNonPositivePostable`, and either remove
`postAccount`'s zero-total skip or re-key it to "the bill has no charge lines".
Add a test asserting a zero-net bill WITH lines still posts. Separately, RevOps
should decide whether a fully-discounted account should receive a zero-value
invoice — that is a product decision, not a defect, and it is the only part of
this entry that needs a business answer.

---

## 13. 🔴 The DB-gated test suite destroys a co-located dev stack

**Where:** `tests/db/billrun-db-roles.integration.test.ts`
(`beforeAll`/`afterAll`), `vitest.integration.config.ts`, `npm run test`.

**Technical.** Three separate hazards, all confirmed live on 2026-09-17:

1. **It drops the `kestra` database.** `afterAll` runs
   `DROP DATABASE IF EXISTS "kestra" WITH (FORCE)` — outside `DATABASE_URL`,
   against the whole cluster. `FORCE` terminates every live connection first, so a
   running engine lost all Hikari connections at once (`SQLSTATE(08006)`), each
   queue poller logged `Fatal error while polling ... Initiating shutdown`, and
   the container exited 0 with **every deployed flow gone**.
2. **It rewrites cluster-level role passwords.** `ALTER ROLE app_runtime /
   rating_runtime / billrun_runtime WITH PASSWORD 'bm14-test-only-pw'`. Roles are
   cluster-scoped, so the dev app then fails `28P01` and every flow DB task fails
   authentication. Restoring the password is not enough on its own — the app's
   connection pool holds the old credential until it is restarted.
3. **The promised "skip loudly" never fires.** Each suite carries
   `describe.skipIf(!DATABASE_URL)`, but `db/client.ts` imports `lib/config.ts` at
   module load and throws `Invalid environment configuration.` first, so every
   DB-gated file **errors** instead of skipping.

Consequently `npm run test` with a dev `.env` exported destroys the local stack,
and the config's own comment about skipping is misleading.

**ELI5.** Running the full test suite against your development database doesn't
just wipe that database — it also deletes the workflow engine's database and
changes the shared login passwords, so the app and the engine both stop working
until you put them back.

**Recommendation.** Point `DATABASE_URL` at a **separate Postgres instance**, not
merely a different database in the same cluster; or stop the engine for the run
and rebuild afterwards (README "Tests, typecheck and lint" documents both, with
the recovery sequence). The durable fix is to scope the teardown to the target
database and stop rewriting cluster-level roles — `bm22 §21`'s "disposable
database" wording understates the blast radius and should be amended with it.

---

## 14. 🟡 No credit-note path — a negative-total bill fails loudly at posting

**Where:** `services/billing/post-run.ts`; plan §13 (out of scope).

**Technical.** A negative `total_amount` is a credit position — money owed **to**
the customer — and has real economic substance. The zero-invoice skip (§11) is
therefore deliberately scoped to *exactly* zero, never `<= 0`, with a
`[CRITICAL]` test on that edge: suppressing a negative would understate the
liability and silently deny the customer a credit. Nothing else handles it
either, so such a bill reaches posting and is rejected by
`document_line_amount_check` (`amount > 0`), parking the account with the same
opaque "unexpected error" message.

**ELI5.** If we ever owe a customer money instead of charging them, the system
can't issue that credit — it just fails with an unhelpful error.

**Recommendation.** Leave the skip narrow (never widen it to `<= 0`). When a
credit-note capability is scoped, give a negative total a **clear parked reason**
instead of the generic failure, so the operator sees what happened. Until then
this is correct-but-unfriendly behaviour, not a data-integrity risk.
