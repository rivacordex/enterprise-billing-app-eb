"use server";

import { revalidatePath } from "next/cache";

import { requirePermission } from "@/auth/guard";
import { LEVELS, PERMISSIONS } from "@/auth/permission-constants";
import { isRedirectError } from "@/lib/errors";
import { retireOffering } from "@/services/product/retire-offering";
import { retireOfferingSchema } from "@/validation/product/retire-offering.schema";

export type RetireOfferingActionResult =
  | { ok: true; offeringId: string }
  | {
      ok: false;
      code: "VALIDATION_ERROR";
      fieldErrors: Record<string, string[]>;
    }
  | { ok: false; code: "OFFERING_NOT_FOUND" }
  | { ok: false; code: "OFFERING_NOT_OBSOLETE" }
  | { ok: false; code: "RETIRE_BLOCKED_BY_SUBSCRIPTIONS"; liveCount: number }
  | { ok: false; code: "FORBIDDEN" }
  | { ok: false; code: "SERVER_ERROR" };

// pm23-spec §3.3, re-purposed pm43 I5. Retire is now OBSOLETE → RETIRED only,
// behind the subscription gate — the old dual-purpose Retire/Discard is gone
// (discard is pm44's hard delete). Gated at products:DELETE (D6, architecture
// §4). A blocked retire returns the live count so the dialog can name it (D4).
export async function retireOfferingAction(
  offeringId: string,
  rawInput: unknown,
): Promise<RetireOfferingActionResult> {
  let actorId: string;
  try {
    ({ userId: actorId } = await requirePermission(
      PERMISSIONS.PRODUCTS,
      LEVELS.DELETE,
    ));
  } catch (error) {
    if (isRedirectError(error)) {
      return { ok: false, code: "FORBIDDEN" };
    }
    return { ok: false, code: "SERVER_ERROR" };
  }

  const parsed = retireOfferingSchema.safeParse(rawInput);
  if (!parsed.success) {
    return {
      ok: false,
      code: "VALIDATION_ERROR",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  let result;
  try {
    result = await retireOffering(offeringId, parsed.data, actorId);
  } catch {
    return { ok: false, code: "SERVER_ERROR" };
  }

  if (!result.ok) {
    return result.code === "RETIRE_BLOCKED_BY_SUBSCRIPTIONS"
      ? { ok: false, code: result.code, liveCount: result.liveCount }
      : { ok: false, code: result.code };
  }

  revalidatePath("/products/manage-products");
  revalidatePath("/products/product-offering");

  return { ok: true, offeringId: result.offeringId };
}
