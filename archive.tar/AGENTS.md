<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

<!--
## Change Configuration
Read the following files in order before implementing
or making any architectural decision related to the change required

1. `context/_change-database-seeds-refactor-plan.md` 
2. `context/architecture.md` 

Update `context/general-change-tracker.md` after each meaningful general implementation change.
-->
 

## Billing Module Update Context

Read the following files in order before implementing
or making any architectural decision related to the Billing (Bill Run) Module:

1. `context/billing-management/billmgmt-update-overview.md` — current update's definition, goals, features, and scope
2. `context/billing-management/billmgmt-project-overview.md` — product spec: overview, core user flow, in/out of scope, success criteria
3. `context/billing-management/billmgmt-architecture.md` — system structure, boundaries, storage model, and Module Invariants
4. `context/billing-management/billmgmt-ui-context.md` — theme, colors, typography, and component conventions
5. `context/billing-management/billmgmt-code-standards.md` — implementation rules and conventions
6. `context/billing-management/billmgmt-ai-workflow-rules.md` — development workflow, scoping rules, and delivery approach
7. `context/billing-management/billmgmt-known-issues.md` — known/deferred defects and interim mitigations
8. `context/billing-management/billmgmt-progress-tracker.md` — current phase, completed work, open questions, and next steps

Update `context/billing-management/billmgmt-progress-tracker.md` after each meaningful implementation change.

Read also the general context document to support the changes as referenced by the context files above:
1. `context/architecture.md` — system structure, boundaries, storage model, and invariants  
2. `context/code-standards.md`— implementation rules and conventions
3. `context/ai-workflow-rules.md` — development workflow, scoping rules, and delivery approach
4. `context/ui-context.md` — theme, colors, typography, and component conventions

 
