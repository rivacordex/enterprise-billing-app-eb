import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ShieldCheck } from "lucide-react";

import { firstValue } from "@/lib/search-params";
import { requirePermission } from "@/auth/guard";
import { LEVELS, PERMISSIONS } from "@/auth/permission-constants";
import { meetsLevel } from "@/types/permissions";
import { buttonVariants } from "@/components/ui/button";
import { RejectDialog } from "@/components/billing/reject-dialog";
import { RerunDialog } from "@/components/billing/rerun-dialog";
import { RunDetailTabs } from "@/components/billing/run-detail-tabs";
import { RunStatusBadge } from "@/components/billing/run-status-badge";
import { StallBanner } from "@/components/billing/stall-banner";
import { TriggerRunDialog } from "@/components/billing/trigger-run-dialog";
import { billRunStallThresholdMinutes } from "@/lib/config";
import { formatCalendarDate } from "@/lib/formatters";
import { getRunDetail } from "@/services/billing/read/get-run-detail";
import { getStageTimeline } from "@/services/billing/read/get-stage-timeline";
import { listAccountBills } from "@/services/billing/read/list-account-bills";
import { listUncharged } from "@/services/billing/read/list-uncharged";
import { listExceptions } from "@/services/billing/read/list-exceptions";
import { listErrors } from "@/services/billing/read/list-errors";
import { listRejectedPending } from "@/services/billing/read/list-rejected-pending";
import { getDistribution } from "@/services/billing/read/get-distribution";
import { listRunAudit } from "@/services/billing/read/list-run-audit";
import { isStalled } from "@/services/billing/stall";
import {
  getAppLocale,
  getAppTimezone,
} from "@/services/system-config/app-config-read.service";
import { billRunIdSchema } from "@/validation/billing/run-id.schema";
import { runDetailSearchParamsSchema } from "@/validation/billing/run-detail.schema";

// bm04-spec §Implementation §9, code-standards §3.1/§3.6. Guard → parse
// params → read → compose tabs. Live status, uncached (Inv. #12). bm05 adds
// the Customers & Bills read (§Implementation §5); bm07 adds the Uncharged/
// Errors/Audit reads — each fetched only for its own active tab, same idiom as
// the Workflow timeline below.
export const dynamic = "force-dynamic";

interface BillRunDetailPageProps {
  params: Promise<{ runId: string }>;
  searchParams: Promise<{ tab?: string | string[] }>;
}

export async function generateMetadata({
  params,
}: BillRunDetailPageProps): Promise<Metadata> {
  const { runId } = await params;
  return { title: `Bill Run — ${runId}` };
}

export default async function BillRunDetailPage({
  params,
  searchParams,
}: BillRunDetailPageProps): Promise<React.JSX.Element> {
  const { permissionMap } = await requirePermission(
    PERMISSIONS.BILLRUN_VIEW,
    LEVELS.READ,
  );

  const { runId: rawRunId } = await params;
  const idResult = billRunIdSchema.safeParse(rawRunId);
  if (!idResult.success) {
    notFound();
  }

  const detail = await getRunDetail(idResult.data);
  if (!detail) {
    notFound();
  }

  const rawSearch = await searchParams;
  const parsedSearch = runDetailSearchParamsSchema.parse({
    tab: firstValue(rawSearch.tab),
  });

  // The run's own status is passed in as the floor for the flow bar — see
  // `getStageTimeline`.
  const timeline =
    parsedSearch.tab === "workflow"
      ? await getStageTimeline(detail.billRunId, detail.status)
      : {
          rows: [],
          summary: {
            total: 0,
            processed: 0,
            processingFailed: 0,
            excluded: 0,
            isMidFlight: true,
          },
          flow: { steps: [], currentStage: null },
        };

  const customerBills =
    parsedSearch.tab === "customers"
      ? await listAccountBills(detail.billRunId)
      : [];

  // bm32 — the Uncharged tab now renders two Info-family sections: the redefined
  // uncharged accounts (no `customer_bill_line`, Inv #22) AND the per-record
  // exception surface (BILL_NOTUSED rows + orphans, Inv #25/D32). Both fetched
  // only for the active tab (same idiom as every other tab below).
  const [uncharged, exceptions] =
    parsedSearch.tab === "uncharged"
      ? await Promise.all([
          listUncharged(detail.billRunId),
          listExceptions(detail.billRunId),
        ])
      : [[], []];

  const errors =
    parsedSearch.tab === "errors" ? await listErrors(detail.billRunId) : [];

  const rejectedPending =
    parsedSearch.tab === "errors"
      ? await listRejectedPending(detail.billRunId)
      : [];

  const distribution =
    parsedSearch.tab === "distribution"
      ? await getDistribution(detail.billRunId)
      : null;

  const audit =
    parsedSearch.tab === "audit" ? await listRunAudit(detail.billRunId) : [];

  const locale = await getAppLocale();
  const timezone = getAppTimezone();

  // The Uncharged tab's per-row "Manual DBN/ADJ" deep link lands on
  // /accounts/transactions, which is guarded by `accounts_transactions:READ`.
  // A principal that can view bill runs but lacks accounts_transactions (e.g. a
  // custom role granted only billrun_view — the seeded MANAGER/USER both hold
  // accounts_transactions:EDIT, so this gate is a no-op for them) can't reach it,
  // so gate the link on that permission (show/hide only — the target route
  // re-checks server-side); otherwise it renders as a plain, non-linking hint.
  const canRecover = meetsLevel(
    permissionMap[PERMISSIONS.ACCOUNTS_TRANSACTIONS],
    LEVELS.READ,
  );

  // bm08 — the rerun affordances (the Errors-tab and run-level rerun) are shown
  // only to a `billrun_operate` principal AND only while the run is rerunnable
  // (pre-approval: PROCESSED, or PROCESSING_FAILED to recover a failed run) —
  // otherwise the control would always fail the service's `NOT_RERUNNABLE`
  // guard. Show/hide only; the action re-checks server-side (code-standards §8).
  const canOperate = meetsLevel(
    permissionMap[PERMISSIONS.BILLRUN_OPERATE],
    LEVELS.EDIT,
  );
  const rerunnable =
    detail.status === "PROCESSED" || detail.status === "PROCESSING_FAILED";
  const canRerun = canOperate && rerunnable;

  // bm12 — a CANCELLED run re-materializes its period by re-triggering the SAME
  // run row (trigger-run.ts's CANCELLED path; the `(cycle, period_start)` unique
  // key prevents a second row). Since CANCELLED is terminal, the run never
  // resurfaces on the Current tab's operable "Run" affordance — so the re-trigger
  // control returns here on the detail header instead (spec §Visual — "the
  // operable Run affordance returns"). Not the RerunDialog: `rerunRun` rejects a
  // CANCELLED run (`NOT_RERUNNABLE`); a re-trigger is `triggerRun`. Show/hide
  // only — the trigger action re-checks `billrun_operate:EDIT` server-side.
  const canRetrigger = canOperate && detail.status === "CANCELLED";

  // bm10 — the four-eyes money gate lives on its own route
  // (`/billing/bill-runs/[runId]/approve`, `billrun_approve:EDIT`). Shown
  // only while the run is awaiting approval; show/hide only — the approve
  // page and action re-check server-side.
  const canApprove = meetsLevel(
    permissionMap[PERMISSIONS.BILLRUN_APPROVE],
    LEVELS.EDIT,
  );
  const approvable = detail.status === "PROCESSED";

  // bm17 — Reject shares the Approve gate (`billrun_approve`, and only while
  // the run is pre-approval/`PROCESSED`) — never a bare row action (spec
  // "Never a bare row action for either"). Show/hide only; the action
  // re-checks server-side.
  const canReject = canApprove && approvable;

  // bm11 — the Post affordance shares the same `/approve` route (it
  // branches server-side on the live run status, bm11-spec §Visual): once
  // `APPROVED`, the route renders `PostingProgressView` instead of the
  // approve checklist. Shown for `APPROVED` (not yet started) and `POSTING`
  // (resumable — "Resume posting" reopens the same progress view).
  const postable = detail.status === "APPROVED" || detail.status === "POSTING";

  // bm12 — the `StallBanner` (Check status / Cancel run) is a derived-state,
  // operator-only affordance: shown only when the run is genuinely stalled
  // AND the viewer holds `billrun_operate` (same show/hide convention as
  // Rerun/Approve/Post above) — a `billrun_view`-only principal sees the run
  // status normally but no action to check or cancel it.
  const stalled = isStalled(detail, new Date(), billRunStallThresholdMinutes);

  return (
    <main className="space-y-6 p-6">
      <header className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="font-mono text-h1 font-semibold text-foreground">
            {detail.billRunId}
          </h1>
          <RunStatusBadge status={detail.status} />
          <div className="ms-auto flex items-center gap-2">
            {canApprove && approvable && (
              <Link
                href={`/billing/bill-runs/${detail.billRunId}/approve`}
                className={buttonVariants()}
              >
                <ShieldCheck aria-hidden="true" />
                Approve &amp; Post
              </Link>
            )}
            {canApprove && postable && (
              <Link
                href={`/billing/bill-runs/${detail.billRunId}/approve`}
                className={buttonVariants()}
              >
                <ShieldCheck aria-hidden="true" />
                {detail.status === "APPROVED" ? "Post" : "Resume posting"}
              </Link>
            )}
            {canReject && (
              <RejectDialog
                billRunId={detail.billRunId}
                accountIds={[]}
                variant="neutral"
              />
            )}
            {canRerun && (
              <RerunDialog
                billRunId={detail.billRunId}
                accountIds={[]}
                triggerLabel="Rerun"
                variant="neutral"
              />
            )}
            {canRetrigger && (
              <TriggerRunDialog
                billRunId={detail.billRunId}
                cycleName={detail.cycleName}
                periodStart={detail.periodStart}
                periodEnd={detail.periodEnd}
              />
            )}
          </div>
        </div>
        <p className="text-body text-muted-foreground">
          {detail.cycleName} · Period {formatCalendarDate(detail.periodStart)} –{" "}
          {formatCalendarDate(detail.periodEnd)}
        </p>
      </header>

      {canOperate && stalled && (
        <StallBanner
          billRunId={detail.billRunId}
          lastProgressAt={detail.lastProgressAt}
          canCancel={detail.status === "PROCESSING"}
          locale={locale}
          timezone={timezone}
        />
      )}

      <RunDetailTabs
        runId={detail.billRunId}
        runStatus={detail.status}
        activeTab={parsedSearch.tab}
        timeline={timeline}
        customerBills={customerBills}
        uncharged={uncharged}
        exceptions={exceptions}
        errors={errors}
        rejectedPending={rejectedPending}
        distribution={distribution}
        audit={audit}
        canRecover={canRecover}
        canRerun={canRerun}
        canOperate={canOperate}
        canApprove={canApprove}
        locale={locale}
        timezone={timezone}
      />
    </main>
  );
}
