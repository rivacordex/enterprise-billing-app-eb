"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

import { activateOfferingAction } from "@/actions/product/activate-offering.action";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Field, FieldLabel } from "@/components/ui/field";
import { Textarea } from "@/components/ui/textarea";

export interface ActivateOfferingDialogProps {
  trigger: React.ReactNode;
  offeringId: string;
  offeringName: string;
  offeringVersion: number;
}

// pm42-spec D6. Keeps its accent confirm button. The revised copy states the two
// consequences of activation: this version becomes orderable, and the family's
// currently-active version is superseded to OBSOLETE (not RETIRED — pm42 D3) yet
// keeps billing its existing subscriptions unchanged (Inv. #6/#17). No
// precondition copy appears: the release checks moved to submit-for-testing
// (pm42 D2), so by the time a version reaches Activate they cannot fail. The
// optional Reason is captured in the audit payload, never a column.
export function ActivateOfferingDialog({
  trigger,
  offeringId,
  offeringName,
  offeringVersion,
}: ActivateOfferingDialogProps): React.JSX.Element {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleOpenChange(nextOpen: boolean): void {
    if (isSubmitting) return;
    if (nextOpen) {
      setReason("");
    }
    setOpen(nextOpen);
  }

  async function handleActivateConfirm(): Promise<void> {
    setIsSubmitting(true);
    try {
      const result = await activateOfferingAction(offeringId, { reason });

      if (result.ok) {
        setOpen(false);
        toast.success(
          result.supersededOfferingId
            ? "Offering activated — previous version marked obsolete"
            : "Offering activated",
        );
        router.refresh();
      } else if (result.code === "FORBIDDEN") {
        toast.error("You don't have permission to do that.");
      } else if (result.code === "OFFERING_NOT_FOUND") {
        toast.error("This offering no longer exists. Refreshing...");
        setOpen(false);
        router.refresh();
      } else if (result.code === "OFFERING_NOT_TESTING") {
        toast.error("This version is no longer in testing. Refreshing...");
        setOpen(false);
        router.refresh();
      } else {
        // VALIDATION_ERROR / SERVER_ERROR — handled defensively.
        toast.error("Something went wrong. Please try again.");
      }
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Activate offering</DialogTitle>
        </DialogHeader>

        <p className="text-body-sm text-muted-foreground">
          <strong>{offeringName}</strong> v{offeringVersion} becomes orderable.
          The version currently active becomes obsolete — existing subscriptions
          keep billing from it unchanged.
        </p>

        <Field>
          <FieldLabel htmlFor="activate-reason">Reason (optional)</FieldLabel>
          <Textarea
            id="activate-reason"
            rows={2}
            maxLength={500}
            placeholder="Q3 rate refresh"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            disabled={isSubmitting}
          />
        </Field>

        <DialogFooter>
          <Button
            type="button"
            variant="ghost"
            disabled={isSubmitting}
            onClick={() => handleOpenChange(false)}
          >
            Cancel
          </Button>
          {/* ui-context §9: the featured-CTA accent is reserved for this one
              confirm action. */}
          <Button
            type="button"
            disabled={isSubmitting}
            onClick={() => void handleActivateConfirm()}
            className="bg-[color:var(--action-cta-bg)]"
          >
            {isSubmitting && <Loader2 className="animate-spin" />}
            Activate
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
