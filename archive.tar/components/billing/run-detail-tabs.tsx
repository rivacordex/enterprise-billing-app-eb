// bm04-spec §Implementation §9, code-standards §3.3/§3.7. The run-detail
// tab switcher — a plain `<Link ?tab=>` (view state in the URL), server
// component (no interaction beyond navigation, so no 'use client' leaf is
// needed here — mirrors `components/billing/bill-run-list.tsx`'s tab nav).
// Workflow (bm04), Customers & Bills (bm05), and Uncharged/Errors/Audit
// (bm07) are all populated.

import Link from "next/link";

import { AuditTable } from "@/components/billing/audit-table";
import { CustomerBillTable } from "@/components/billing/customer-bill-table";
import { DistributionTab } from "@/components/billing/distribution-tab";
import { ErrorsTable } from "@/components/billing/errors-table";
import { RunFlowProgressBar } from "@/components/billing/run-flow-progress";
import { StageTimeline } from "@/components/billing/stage-timeline";
import { UnchargedTable } from "@/components/billing/uncharged-table";
import type { AuditLogRow } from "@/types/audit-log";
import type { RunDetailTab } from "@/validation/billing/run-detail.schema";
import { RUN_DETAIL_TABS } from "@/validation/billing/run-detail.schema";
import type {
  CustomerBillRow,
  DistributionView,
  ErrorRow,
  ExceptionRow,
  RejectedPendingRow,
  RunFlowProgress,
  RunStatus,
  StageTimelineRow,
  StageTimelineSummary,
  UnchargedRow,
} from "@/types/billing";

const TAB_LABELS: Record<RunDetailTab, string> = {
  workflow: "Workflow",
  customers: "Customers & Bills",
  uncharged: "Uncharged",
  errors: "Errors",
  distribution: "Distribution",
  audit: "Audit",
};

export interface RunDetailTabsProps {
  runId: string;
  runStatus: RunStatus;
  activeTab: RunDetailTab;
  timeline: {
    rows: StageTimelineRow[];
    summary: StageTimelineSummary;
    flow: RunFlowProgress;
  };
  customerBills: CustomerBillRow[];
  uncharged: UnchargedRow[];
  exceptions: ExceptionRow[];
  errors: ErrorRow[];
  rejectedPending: RejectedPendingRow[];
  distribution: DistributionView | null;
  audit: AuditLogRow[];
  canRecover: boolean;
  canRerun: boolean;
  canOperate: boolean;
  canApprove: boolean;
  locale: string;
  timezone: string;
}

export function RunDetailTabs({
  runId,
  runStatus,
  activeTab,
  timeline,
  customerBills,
  uncharged,
  exceptions,
  errors,
  rejectedPending,
  distribution,
  audit,
  canRecover,
  canRerun,
  canOperate,
  canApprove,
  locale,
  timezone,
}: RunDetailTabsProps): React.JSX.Element {
  return (
    <div className="space-y-4">
      <nav
        aria-label="Bill run detail tabs"
        className="flex gap-1 border-b border-border"
      >
        {RUN_DETAIL_TABS.map((tab) => {
          const active = activeTab === tab;
          return (
            <Link
              key={tab}
              href={`?tab=${tab}`}
              aria-current={active ? "page" : undefined}
              className={
                active
                  ? "border-b-2 border-[color:var(--color-primary-500)] px-4 py-2 text-body-sm font-semibold text-foreground"
                  : "border-b-2 border-transparent px-4 py-2 text-body-sm font-medium text-muted-foreground hover:text-foreground"
              }
            >
              {TAB_LABELS[tab]}
            </Link>
          );
        })}
      </nav>

      {activeTab === "workflow" ? (
        <div className="space-y-4">
          {runStatus === "CANCELLED" ? (
            // A cancelled run was reset (accounts back to PENDING), so a
            // pipeline-progress bar would read as in-progress. Suppress it and
            // show a plain note; the per-account grid below still reflects the
            // reset state and the run status badge above says CANCELLED.
            <p className="text-body-sm text-muted-foreground">
              This run was cancelled — the pipeline progress bar is hidden.
            </p>
          ) : (
            <RunFlowProgressBar runId={runId} flow={timeline.flow} />
          )}
          <StageTimeline rows={timeline.rows} summary={timeline.summary} />
        </div>
      ) : activeTab === "customers" ? (
        <CustomerBillTable
          billRunId={runId}
          rows={customerBills}
          locale={locale}
          timezone={timezone}
        />
      ) : activeTab === "uncharged" ? (
        <UnchargedTable
          runId={runId}
          rows={uncharged}
          exceptions={exceptions}
          canRecover={canRecover}
          locale={locale}
        />
      ) : activeTab === "errors" ? (
        <ErrorsTable
          runId={runId}
          rows={errors}
          canRerun={canRerun}
          rejectedPending={rejectedPending}
        />
      ) : activeTab === "distribution" ? (
        distribution ? (
          <DistributionTab
            view={distribution}
            canOperate={canOperate}
            canApprove={canApprove}
            locale={locale}
            timezone={timezone}
          />
        ) : (
          <p className="text-body-sm text-muted-foreground">
            Distribution has not started yet — it becomes available once the run
            is Invoiced.
          </p>
        )
      ) : (
        <AuditTable rows={audit} timezone={timezone} />
      )}
    </div>
  );
}
